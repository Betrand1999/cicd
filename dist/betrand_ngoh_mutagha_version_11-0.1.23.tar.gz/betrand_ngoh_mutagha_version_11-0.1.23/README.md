###
git clone https://github.com/yourusername/your-repo.git
###
cd your-repo

####
Go to steup.py edit the version
Go to setup edit the user name
with python cannot rebuild artifact project with same name
######




####
Build the Project
python3 -m venv venv
source venv/bin/activate


 ####
 It downloads and installs the package from PyPI into your local Python environment.
 pip install <setup_project_name> same name in pypi
#####

#####
to run it locally
python -m <the_root_directory_name_that_contain_your_application_with.app> 
example python -m hello_world_app.app

####



